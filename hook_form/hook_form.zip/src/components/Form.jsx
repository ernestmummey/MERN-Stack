import React, {useState} from  'react';
    
    
const Form = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [fError, setFError] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    
    
    const createUser = (e) => { 
        e.preventDefault();
        const user = {firstName, lastName, email, password, confirmPassword};
        console.log("Welcome", user)
    }

    const fNameError = (e) => {
        setFirstName(e.target.value);
        if(e.target.value.length < 3) {
            setFError('First Name must be at least 2 characters');
        }else{
            setFError('')
        }
    }
    const lNameError = (e) => {
        setLastName(e.target.value)
        if(e.target.value.length < 3) {
            setLastNameError('Last Name must be at least 2 characters');
        }else{
            setLastNameError('')
        }
    }
    const eError = (e) => {
        setEmail(e.target.value)
        if(e.target.value.length < 5) {
            setEmailError('Email must be at least 2 characters');
        }else{
            setEmailError('')
        }
    }
    const pError = (e) => {
        setPassword(e.target.value)
        if(e.target.value.length < 8) {
            setPasswordError('Password must be at least 8 characters');
        }else{
            setPasswordError('')
        }
    }
    const confirmpError = (e) => {
        setConfirmPassword(e.target.value)
        if(e.target.value !== password) {
            setConfirmPasswordError('Password must match');
        }else{
            setConfirmPasswordError('')
        }
    }

    
    return(
    <div>
        <form onSubmit = {createUser}>
            <div>
                <label>First Name: </label> 
                <input type="text" onChange={fNameError} value = {firstName} />
                <p style={{color: 'red'}}>{fError}</p>
            </div>
            <div>
                <label>Last Name: </label> 
                <input type="text" onChange={lNameError} value = {lastName}/>
                <p style={{color: 'red'}}>{lastNameError}</p>
            </div>
            <div>
                <label>Email Address: </label> 
                <input type="text" onChange= {eError} value = {email}/>
                <p style={{color: 'red'}}>{emailError}</p>
            </div>
            <div>
                <label>Password: </label>
                <input type="text" onChange={pError} value = {password} />
                <p style={{color: 'red'}}>{passwordError}</p>
            </div>
            <div>
                <label> Confirm Password: </label>
                <input type="text" onChange={confirmpError} value ={confirmPassword} />
                <p style={{color: 'red'}}>{confirmPasswordError}</p>
            </div>
            <input type="submit" value="create" />
        </form>


        <h2>Your Form Data</h2>
        <p>First Name: {firstName}</p>
        <p>Last Name: {lastName}</p>
        <p>email: {email}</p>
        <p>Password: {password}</p>
        <p>Confirm Password: {confirmPassword}</p>
    </div>
    );
};
    
export default Form;